class OrderItemsController < ApplicationController

    skip_before_action :verify_authenticity_token

    def create
        @order = current_order
        @order_item = @order.order_items.new(order_params)
        @order.save
        session[:order_id] = @order.id
    end



    def update
        @order = current_order
        @order_item = @order.order_items.find(params[:id])
        @order_item.update_attributes(order_params)
        redirect_to root_path
        #@order_items = current_order.order_items
    end

    def destroy
        @order = current_order
        @order_item = @order.order_items.find(params[:id])
        @order_item.destroy
        redirect_to root_path

        #@order_items = current_order.order_items
        
    end

    def show
        @order = OrderItem.find(params[:id])
        redirect_to cards_path(@order)
    end


    private

    def order_params
        params.require(:order_item).permit(:product_id, :quantity)
    end
end